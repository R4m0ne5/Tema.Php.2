<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações do País</title>
</head>
<?php
    if (isset($_GET['codigo'])) {
        $codigo_pais = $_GET['codigo'];
        
        $url = 'https://restcountries.com/v3.1/alpha/' . $codigo_pais;

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        ]);

        $response = curl_exec($curl);

        curl_close($curl);

        $pais = json_decode($response, true)[0];

            $nome_do_pais = $pais['name']['common'];
            $bandeira = $pais['flags']['png'];
            $continente = $pais['continents'][0];
            $populacao = number_format($pais['population']);
    }
?>
<body>
    <h1><?= $nome_do_pais; ?></h1>
    <img src="<?= $bandeira; ?>" alt="Bandeira de <?= $nome_do_pais; ?>" class="bandeira">
    <p>Continente: <?= $continente; ?></p>
    <p>População: <?= $populacao; ?> habitantes</p>
    <div class="voltar">
        <a href="index.php">Voltar para a lista de países</a>
    </div>
</body>
</html>
